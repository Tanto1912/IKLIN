function Dashboard() {
  return (
    <div>
      <h1>INI DASHBOARD</h1>
    </div>
  );
}

export default Dashboard;
